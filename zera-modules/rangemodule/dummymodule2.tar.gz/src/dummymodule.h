#ifndef DUMMYMODULE_H
#define DUMMYMODULE_H

#include <QObject>
#include <zera-modules/abstractmodulefactory.h>

class DummyModuleFactory : public QObject, public MeasurementModuleFactory
{
  Q_OBJECT
  Q_PLUGIN_METADATA(IID "de.zera.ModuleManager.MeasuringModule" FILE "dummymodule.json")
  Q_INTERFACES(MeasurementModuleFactory)
  
public:
  DummyModuleFactory();
  ZeraModules::VirtualModule *createModule();
  void loadSession(QFile *sessionFile);
  void saveSession(QFile *fileName);
  QList<ZeraModules::VirtualModule*> listModules();
};

#endif // DUMMYMODULE_H
