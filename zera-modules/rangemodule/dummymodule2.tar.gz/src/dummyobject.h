#ifndef DUMMYOBJECT_H
#define DUMMYOBJECT_H

#include <virtualmodule.h>

class DummyObject : public ZeraModules::VirtualModule
{
public:
  DummyObject();
};

#endif // DUMMYOBJECT_H
