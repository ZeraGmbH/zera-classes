#include "dummyobject.h"

DummyObject::DummyObject()
{
}
