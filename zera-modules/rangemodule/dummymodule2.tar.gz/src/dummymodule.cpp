#include "dummymodule.h"


DummyModuleFactory::DummyModuleFactory()
{
}
